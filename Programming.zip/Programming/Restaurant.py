from Customer import Customer
from Staff import Staff
from Menu import Menu
from Reservation import Reservation
def main():
    
    menu = Menu()
    reservations = {}
    restaurant_details = "Restaurant XYZ, Address, Contact Info"  

    Reservation.populate_items(menu)
    
    while True:
        user_role = input("Welcome to the Restaurant Management System! \nAre you a 'customer' or 'staff'? (Type 'exit' to quit): ").lower()

        if user_role == 'exit':
            break

        if user_role == 'customer':
            customer_name = input("Please enter your name: ")
            customer = Customer(customer_name, menu)

            while True:
                print("\nCustomer Options:")
                print("1. View Menu\n2. Make a Reservation\n3. View Your Reservation\n4. Cancel Your Reservation\n5. Update Your Reservation\n6. Exit")
                customer_action = input("Choose an action: ")

                if customer_action == '1':
                    customer.view_menu()
                elif customer_action == '2':
                    customer.make_Reservation(menu, reservations)
                elif customer_action == '3':
                    customer.view_Reservation(reservations)
                elif customer_action == '4':
                    customer.cancel_Reservation(reservations)
                elif customer_action == '5':
                    customer.update_Reservation(reservations)
                elif customer_action == '6':
                    break
                else:
                    print("Invalid choice, please try again.")

        elif user_role == 'staff':
            staff = Staff(menu, reservations)

            while True:
                print("\nStaff Options:")
                print("1. Display Menu\n2. Display Restaurant Details\n3. View All Reservations\n4. View Customer Reservation\n5. Update Customer Reservation\n6. Cancel Customer Reservation\n7. Add Menu Item\n8. Update Menu Item\n9. Remove Menu Item\n10. Search Menu Description\n11. Exit")
                staff_action = input("Choose an action: ")

                if staff_action == '1':
                    staff.display_menu()
                elif staff_action == '2':
                    staff.display_restaurant_details(restaurant_details)
                elif staff_action == '3':
                    staff.view_all_reservations()
                elif staff_action == '4':
                    staff.view_customer_reservation()
                elif staff_action == '5':
                    staff.update_customer_reservation()
                elif staff_action == '6':
                    staff.cancel_customer_reservation()
                elif staff_action == '7':
                    staff.add_menu_item()
                elif staff_action == '8':
                    staff.update_menu_item()
                elif staff_action == '9':
                    staff.remove_menu_item()
                elif staff_action == '10':
                    staff.search_menu_description()
                elif staff_action == '11':
                    break
                else:
                    print("Invalid choice, please try again.")

        else:
            print("Invalid role. Please enter 'customer' or 'staff'.")

if __name__ == "__main__":
    main()
