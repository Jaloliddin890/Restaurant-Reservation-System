
class Reservation:
    def __init__(self, customer_name, date, time, guests, menu):
        self.customer_name = customer_name
        self.date = date
        self.time = time
        self.guests = guests
        self.menu = menu
        self.selected_meals = []
# This function added specific meal to list of meals
        
    def add_meal(self, meal_id):
        if len(self.selected_meals) < 10 and meal_id in self.menu.items:
            self.selected_meals.append(self.menu.items[meal_id])
        else:
            print("Cannot add more meals. Maximum 10 allowed or meal not in menu.")

# This function removed specific meal from list of meals
    def remove_meal(self, meal_id):
        self.selected_meals = [meal for meal in self.selected_meals if meal != self.menu.items[meal_id]]

# This function update specific meal which is exist in list of meals
    def update_meal(self):
        print("Current selected meals:")
        for meal in self.selected_meals:
            print(f" - {meal['name']}")
        
        while True: 
            choice = input("Would you like to 'add' meal(for adding = 1 ), \n 'remove' meal(for removing = 2), \n 'done' updating??? (for done = 3)  : ")

            if choice == '1':
                meal_id = int(input("Enter meal ID to add:  "))
                if meal_id in self.menu.items:
                    self.add_meal(meal_id)
                else: 
                    print("Meal ID not fount in menu ! ! ! ")
            if choice == '2':
                meal_id = int(input("Enter meal ID to remove :  "))
                if any(meal['name'] == self.menu.items[meal_id]['name'] for meal in self.selected_meals):
                    self.remove_meal(meal_id)
                else: 
                    print("Meal ID not found in your selection.")

            if choice == '3':
                break

    def calculate_total(self):
        return sum(meal['price'] for meal in self.selected_meals)

    def __str__(self):
        reservation_details = f"Reservation for {self.customer_name} on {self.date} at {self.time} for {self.guests} guests.\n"
        reservation_details += "Selected Meals:\n"
        for meal in self.selected_meals:
            reservation_details += f" - {meal['name']} at ${meal['price']}\n"
        reservation_details += f"Total Cost: ${self.calculate_total()}"
        return reservation_details

    @staticmethod
    def populate_items(menu):
        menu.add_item(1, 'Osh', 10, 'Milliy taom, Go`shtli taom')
        menu.add_item(2, 'Manti', 8, 'Milliy taom, Xamirli taom')
        menu.add_item(3, 'Sho`rva', 9, 'Milliy taom, Yog`li taom')
        menu.add_item(4, 'Shashlik', 8, 'Milliy taom, Go`shtli taom')
        menu.add_item(5, 'Lag`mon', 8, 'Milliy taom, Xamirli taom')
        menu.add_item(6, 'Sezar Salat', 5, 'Salat, Yengil taom')
        menu.add_item(7, 'Pizza', 12, 'Italian taom, Fast Food')
        menu.add_item(8, 'burger', 7, 'Americano taom, Fast Food')
        menu.add_item(9, 'Norin', 8, 'Milliy taom, Go`shtli va Xamirli taom')
        menu.add_item(10, 'Somsa', 5, 'Milliy taom, O`zbek Food')


    def make_reservation(name, menu):
        date = input("Enter reservation date (YYYY-MM-DD): ")
        time = input("Enter reservation time (HH:MM): ")
        guests = int(input("Enter number of guests: "))
        reservation = Reservation(name, date, time, guests, menu)

        print("Please select your meals by entering the item number. Type 'done' when finished.")
        print("------------------------------------------------------")
        menu.display_items()
        while True:
            choice = input("Enter meal number (or 'done'): ")
            if choice.lower() == 'done':
                if 1 <= len(reservation.selected_meals) <= 10:
                    break
                else:
                    print("Error: You must select at least one and no more than 10 meals.")
                    continue
            elif choice.isdigit() and int(choice) in menu.items:
                reservation.add_meal(int(choice))
            else:
                print("Invalid choice. Please try again.")

        return reservation

    def cancel_reservation(reservations, name):
        if name in reservations:
            del reservations[name]
            print(f"Reservation for {name} has been canceled.")
        else:
            print("No reservation found for this name.")

    def view_reservation(reservations, name):
        if name in reservations:
            print(reservations[name])
        else:
            print(f"No reservation found for this {name}.")

    def view_all_reservations(reservations):
        if reservations:
            print("\nAll Reservations:")
            for name, reservation in reservations.items():
                print(f"\nReservation for {name}:")
                print(reservation)
        else:
            print("No reservations available.")


