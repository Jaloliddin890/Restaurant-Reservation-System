from Reservation import Reservation
from Menu import Menu
class Customer(Reservation, Menu):
        
    def __init__(self,name, menu):
         self.name = name
         self.menu = menu

    def view_menu(self):
        print("----------------------------------------------------------------")
        self.menu.display_items()
        print("----------------------------------------------------------------")               

    def make_Reservation(self, menu, reservations):
        name = input("Enter your name: ")  
        reservation = Reservation.make_reservation(name, menu)
        reservations[name] = reservation          

    def view_Reservation(self, reservations):
        name = input("Enter your name to view your reservation: ")
        print("----------------------------------------------------------------")         
        return Reservation.view_reservation(reservations, name)    
    
                   
    def cancel_Reservation(self, reservations):
        name = input("Enter your name to cancel your reservation: ")
        print("----------------------------------------------------------------")
        Reservation.cancel_reservation(reservations, name)
        print("----------------------------------------------------------------")
    
    def update_Reservation(self, reservations):
                
      
        name = input("Enter your name to update your reservation: ")
        if name in reservations:
            reservations[name].update_meal()
        else:
            print("----------------------------------------------------------------")
            print("Reservation not found.")
            print("----------------------------------------------------------------")

    def view_restaurant_details(self, restaurant_details):
                    
        print("----------------------------------------------------------------")
        print(restaurant_details)
        print("----------------------------------------------------------------")

           