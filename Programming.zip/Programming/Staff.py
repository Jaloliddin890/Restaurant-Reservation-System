
from Menu import Menu
from Reservation import Reservation
class Staff(Menu, Reservation):
    
    def __init__(self, menu, reservations):
        self.reservations = reservations
        self.menu = menu
    
    def display_menu(self):
        print("----------------------------------------------------------------")
        self.menu.display_items()
        print("----------------------------------------------------------------")

    def display_restaurant_details(self, restaurant_details):
        print("----------------------------------------------------------------")
        print(restaurant_details)
        print("----------------------------------------------------------------")

    def view_all_reservations(self):
        print("----------------------------------------------------------------")
        Reservation.view_all_reservations(self.reservations)
        print("----------------------------------------------------------------")

    def view_customer_reservation(self):
        name = input("Enter the customer's name to view their reservation: ")
        print("----------------------------------------------------------------")
        Reservation.view_reservation(self.reservations, name)
        print("----------------------------------------------------------------") 

    def update_customer_reservation(self):
        name = input("Enter Customer's name: ")
        if name in self.reservations:
            self.reservations[name].update_meal()
        else:
            print("----------------------------------------------------------------")
            print("Reservation not found.")
            print("----------------------------------------------------------------") 

    def cancel_customer_reservation(self):
        name = input("Enter the customer's name to cancel their reservation: ")
        print("----------------------------------------------------------------")
        Reservation.cancel_reservation(self.reservations, name)
        print("----------------------------------------------------------------") 

    def add_menu_item(self):
        item_id = int(input("Enter item ID: "))
        name = input("Enter item name: ")
        price = float(input("Enter item price: "))
        description = input("Enter item description: ")
        self.menu.add_item(item_id, name, price, description)
    
    def update_menu_item(self):
        item_id = int(input("Enter item ID to update: "))
        name = input("Enter new item name (press enter to skip): ")
        price_input = input("Enter new item price (press enter to skip): ")
        description = input("Enter new item description (press enter to skip): ")

        updated_name = name if name else None
        updated_price = float(price_input) if price_input and price_input.isdigit() else None
        updated_description = description if description else None

        self.menu.update_item(item_id, updated_name, updated_price, updated_description)  # Use the menu instance

        print("----------------------------------------------------------------")
        print("Menu item updated.")
        print("----------------------------------------------------------------")       

    def remove_menu_item(self):
        item_id = int(input("Enter item ID to delete: "))
        print("----------------------------------------------------------------")
        self.menu.remove_item(item_id)
        print("----------------------------------------------------------------")

    def search_menu_description(self):
        search_keyword = input("Enter a keyword to search in meal descriptions: ")
        print("----------------------------------------------------------------")
        self.menu.find_from_description(search_keyword)
        print("----------------------------------------------------------------")