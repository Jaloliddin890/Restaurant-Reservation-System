
class Menu:

    def __init__(self):
        self.items = {}

    def add_item(self, item_id, name, price, description):
        if len(self.items) < 10:
            self.items[item_id] = {'name': name, 'price': price, 'description': description}
        else:
            print("Cannot add more than 10 items to the menu.")

    def remove_item(self, item_id):
        if item_id in self.items:
            del self.items[item_id]
        else:
            print("Item not found in the menu.")

    def update_item(self, item_id, name=None, price=None, description=None):
        if item_id in self.items:
            if name:
                self.items[item_id]['name'] = name
            if price:
                self.items[item_id]['price'] = price
            if description:
                self.items[item_id]['description'] = description
        else:
            print("Item not found in the menu.")
    
    def display_items(self):
        for item_id, details in self.items.items():
            print(f"{item_id}: {details['name']} - ${details['price']} - {details['description']}")

    def find_from_description(self, keyword):
        for item_id, details in self.items.items():
            if keyword in details['description']:
                print(f"Found item: {item_id}: {details['name']} - ${details['price']} - {details['description']}")
                return
        print("No item found matching the description.")
        





